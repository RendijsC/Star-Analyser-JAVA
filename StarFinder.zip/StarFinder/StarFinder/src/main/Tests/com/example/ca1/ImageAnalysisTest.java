package com.example.ca1;

import com.example.ca1.ImageAnalysis;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ImageAnalysisTest {
    private ImageAnalysis imageAnalysis;

    @BeforeEach
    public void setUp() {
        imageAnalysis = new ImageAnalysis();
    }

    @Test
    public void testCreateHashMap() {
        // Define a sample array of integers representing pixel values.
        int[] pixels = new int[]{0, 0, -1, 0, 4, -1, -1, -1, 4};

        // Call the createHashMap method from the ImageAnalysis class and store the result.
        HashMap<String, HashMap<Integer, List<Integer>>> result = ImageAnalysis.createHashMap(pixels);

        // Check if the result HashMap contains the "objectMap" key.
        assertTrue(result.containsKey("objectMap"));

        // Check if the result HashMap contains the "objectValue" key.
        assertTrue(result.containsKey("objectValue"));

        // Check if the "objectMap" key in the result HashMap has the expected size of 2.
        assertEquals(2, result.get("objectMap").size());

        // Check if the "objectValue" key in the result HashMap has the expected size of 2.
        assertEquals(2, result.get("objectValue").size());
    }
}
