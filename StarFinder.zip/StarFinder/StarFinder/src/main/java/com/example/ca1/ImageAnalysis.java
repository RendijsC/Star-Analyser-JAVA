package com.example.ca1;

import javafx.scene.control.Label;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.image.*;
import javafx.scene.paint.Color;
import resources.UnionFind;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ImageAnalysis {
    int[] pixels;


    // This method takes an input image, a writable image, an image view, a threshold value,
    // a label, and a tree view as input parameters and converts the input image to black and white.
    public void blackAndWhite(Image image, WritableImage writableImage, ImageView imageView,
                              double threshold, Label number, TreeView treeView) {

        // Get the height and width of the input image.
        int height = (int) image.getHeight();
        int width = (int) image.getWidth();

        // Get the pixel reader and writer for the input and writable images respectively.
        PixelReader pixelReader = image.getPixelReader();
        PixelWriter pixelWriter = writableImage.getPixelWriter();

        // Create an array to store the pixels of the image.
        pixels = new int[width * height];

        // Loop through all the pixels of the input image and write them to the writable image.
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = pixelReader.getColor(x, y);
                pixelWriter.setColor(x, y, color);
            }
        }

        // Loop through all the pixels of the input image again and convert them to black and white based on
        // the threshold value. If the brightness of a pixel is greater than the threshold, the pixel is set to
        // white, otherwise it is set to black.
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                Color color = pixelReader.getColor(j, i);
                if (color.getBrightness() > threshold) {
                    pixelWriter.setColor(j, i, Color.WHITE);
                } else {
                    pixelWriter.setColor(j, i, Color.BLACK);
                }
            }
        }

        // Loop through all the pixels of the input image again and calculate the threshold value for each pixel
        // based on the red, green, and blue components. If the threshold value is greater than the threshold
        // parameter, the pixel is set to white, otherwise it is set to black. Also, store the pixels in an array.
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = pixelReader.getColor(x, y);
                double thresh = color.getRed() * 0.299 + color.getGreen() * 0.587 + color.getBlue() * 0.114;
                Color color1 = thresh > threshold ? Color.WHITE : Color.BLACK;
                if (color1 == Color.BLACK) {
                    pixels[y * width + x] = -1;
                } else {
                    pixels[y * width + x] = y * width + x;
                }
            }
        }

        // Merge the pixels.
        merge(width);

        // Create a hash map of object pixels and store it in objectMap variable.
        HashMap<Integer, List<Integer>> objectMap = createHashMap(pixels).get("objectMap");

        // Count the number of stars and display it in the label.
        countingStars(objectMap, number);

        // Populate the tree view with the object pixels.
        populateTreeView(treeView, objectMap, image);

        // Set the image view to the black and white image.
        imageView.setImage(writableImage);
    }



    // This method merges adjacent white pixels in the image to form stars
    public void merge(int width) {
        // Iterate through all the pixels in the image
        for (int i = 0; i < pixels.length; i++) {
            // Check if the pixel is not black
            if (pixels[i] != -1) {
                // If the pixel on the right is not black and not at the edge of the image, merge them
                if (i + 1 < pixels.length && pixels[i + 1] != -1 && i % width != width - 1)
                    UnionFind.union(pixels, i, i + 1);

                // If the pixel below is not black, merge them
                if (i + width < pixels.length && pixels[i + width] != -1)
                    UnionFind.union(pixels, i, i + width);
            }
        }
    }

    public static HashMap<String, HashMap<Integer, List<Integer>>> createHashMap(int[] pixels) {
        HashMap<Integer, List<Integer>> objectMap = new HashMap<>();  // create hashmap to map root node to its corresponding pixel nodes
        HashMap<Integer, List<Integer>> objectValue = new HashMap<>();  // create hashmap to map root node to its corresponding pixel values

        for(int i = 0; i < pixels.length; i++) {
            if(pixels[i] != -1) {
                int root = UnionFind.find(pixels, i);  // find the root node of the current pixel node
                if(!objectMap.containsKey(root)) {  // if the root node is not in the object map
                    objectMap.put(root, new ArrayList<>());  // add the root node to the object map with an empty list
                    objectValue.put(root, new ArrayList<>());  // add the root node to the object value with an empty list
                }
                objectMap.get(root).add(pixels[i]);  // add the current pixel node to the list of its corresponding root node in the object map
                if(!objectMap.get(root).contains(pixels[i])) {  // if the current pixel node is not already in the list of its corresponding root node in the object map
                    objectMap.get(root).add(pixels[i]);  // add the current pixel node to the list of its corresponding root node in the object map
                }
            }
        }
        HashMap<String, HashMap<Integer, List<Integer>>> result = new HashMap<>();  // create hashmap to hold the result
        result.put("objectMap", objectMap);  // put the object map into the result hashmap
        result.put("objectValue", objectValue);  // put the object value into the result hashmap
        return result;  // return the result hashmap
    }

    // This method counts the number of stars and updates the label with the count
    public void countingStars(HashMap<Integer, List<Integer>> objectValue, Label label) {
        int numberStars = 0;

        // Iterate through all the stars and count them
        for (List<Integer> pix : objectValue.values()) {
            if (!pix.isEmpty()) {
                numberStars++;
            }
        }

        // Update the label with the number of stars
        label.setText(numberStars + "");
    }

    public void populateTreeView(TreeView treeView, HashMap<Integer, List<Integer>> objectValue, Image image) {
        // Get the pixel reader for the image
        PixelReader pixelReader = image.getPixelReader();

        // Create a new tree item as the root of the tree view
        TreeItem<String> root = new TreeItem<>("Stars");
        treeView.setRoot(root);

        // Iterate over the object value hashmap
        for(Integer key : objectValue.keySet()) {
            // Get the list of pixels for the current object key
            List<Integer> value = objectValue.get(key);

            // Calculate the average color of the star
            float r = 0;
            float g = 0;
            float b = 0;
            for(int pixels : value) {
                Color color = pixelReader.getColor(pixels % (int) image.getWidth(), pixels / (int) image.getWidth());
                r += color.getRed();
                g += color.getGreen();
                b += color.getBlue();
            }
            r /= value.size();
            g /= value.size();
            b /= value.size();

            // Create a new tree item for the star with its ID and size
            TreeItem<String> star = new TreeItem<>("Star " + key + " - " + value.size() + " pixels");

            // Add the color information for the star as child tree items
            star.getChildren().add(new TreeItem<>("Sulphur: " + r));
            star.getChildren().add(new TreeItem<>("Hydrogen: " + g));
            star.getChildren().add(new TreeItem<>("Oxygen: " + b));

            // Add the star to the root of the tree view
            root.getChildren().add(star);
        }
    }









}


